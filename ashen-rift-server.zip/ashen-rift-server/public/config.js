// 온라인 서버 주소를 적어 주세요 (Render에서 받은 주소, 끝에 / 없이)
// 예) window.GAME_SERVER = 'https://ashen-rift-server.onrender.com';
// 비워 두면 혼자 하는 오프라인 버전으로 동작해요.
window.GAME_SERVER = '';
